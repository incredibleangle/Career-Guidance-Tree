<?php 

// to include header file 
     include "layouts/header.php";
     include "layouts/header_area.php";
?>
<!--==============================
        Blog Area
    ==============================-->
    <section class="as-blog-wrapper blog-details space-top space-extra-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xxl-8 col-lg-7">
                    <div class="as-blog blog-single">
                        <div class="blog-img">
                            <img src="./education.png" alt="Blog Image">
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <a href="blog.html"><img src="assets/img/blog/author-1-1.png" alt="author">Kevin Perry</a>
                                <a href="blog.html"><i class="far fa-comment"></i>Comments(02)</a>
                                <a href="blog.html"><i class="far fa-book"></i>Study</a>
                            </div>
                            <h2 class="blog-title">how to be successful in life</h2>
                            <p>How do we define our success? Is it because we get a big paycheck, live in an extraordinarily large home, married the hottest guy or girl in the county, or drive the fastest car on the block?
                            </p>
                            <p>Those certainly aren’t measures of success.

Building a business and entrepreneurship requires unique talents and a love for your career. It’s not about frivolous things. It’s about opportunity and your ability to uncover your dream.

</p>
                            <p>There are 8 very simple rules that you can follow to become truly successful.</p>
                            <p>Be Passionate. And do what you for love. If you don’t love it, then why do it? If we build careers or continue in jobs that really aren’t our passion, we’re selling ourselves short. It’s like the guy that is a tech consultant that really wanted to be the lead singer of a band. I’ve written about love and careers before and I think that the takeaway here is that if you really do what YOU want to do, you will be more creative, more motivated, more tuned-in, and much more likely to be very financially and personally prosperous. Katherine Hepburn said it best,</p>
                            <p></p>
                            <blockquote>
                                <p>“If you have to support yourself, you had bloody well better find some way that is going to be interesting.”</p>
                                
                            </blockquote>
                            <p>Work Hard. Don’t ever fool yourself—success comes from really hard work. And you might find that although you’re doing all of the heavy lifting, there is satisfaction in a job well done. But remember that you need to rely on others, so make sure that you surround yourself with colleagues that share your same work ethic.</p>
                            
                            <blockquote>
                          <p>“I do not know anyone who has got to the top without hard work. That is the recipe. It will not always get you to the top, but should get you pretty near.”–Margaret Thatcher.</p>
</blockquote>
                          <p>Be Good. And by that, I mean damn good. Successful people strive for greatness, not mediocrity. So push yourself (and your team) to ensure that you’ve reached your ultimate potential. And be sure to celebrate your wins, that not only breeds confidence among your team, it will keep your colleagues engaged and also will keep your clients or customers enfranchised. If you haven’t read the book from Good to Great, grab a copy.</p>
                          <blockquote>
                            <p></p>
                            James C. Collins said, “Greatness is not a function of circumstance. Greatness, it turns out, is largely a matter of conscious choice, and discipline.”
</blockquote>
                          <p>Focus. Focus always proceeds success—which is not possible without a clear emphasis on what matters most. And leaders constantly need to remind themselves of this vital truth. Focus requires the pursuit of a mission and vision.</P>
                          <blockquote>
                          <p>“Good business leaders create a vision, articulate the vision, passionately own the vision, and relentlessly drive it to completion,” said Jack Welch.</p>
                          </blockquote>
                          <p>Push the Limits. Richard Branson said,</p>
                          <blockquote>
                              <p>“Far too many people don’t excel in life because they are too afraid of taking the necessary steps to achieve their dreams. Some manifest fear as a safeguard from failure; others don’t even try, believing that they are restricted by limits; while too many get caught up in the status quo.”</p>
                          </blockquote>
                          <p>Don’t constrain yourself to thinking inside of the box and don’t allow fear to get in your way. Today, people expect more than ordinary so you need to be extraordinary to get noticed and build strong relationships with your target market. Whether you sell a product or service, you must deliver the utmost experience.</p>

                          <p>Serve. Customer service excellence has always been and will always be one of the critical competitive advantages for any business. Meeting your customer’s needs will help you build a very strong and memorable brand. Be responsive, listen, and observe—then you will create value. Learn from mistakes in service.</p>
                          
                          <blockquote>
                          <p>“Your most unhappy customers are your greatest source of learning.”–Bill Gates.</p>
                          </blockquote>
                          <img src="./education1.jfif" width="500" height="300"alt="Blog Image" class="mt-10 mb-25">
                            
                        </div>
                        <div class="share-links clearfix ">
                            <div class="row justify-content-between">
                                <div class="col-md-auto">
                                    <span class="share-links-title">Tags:</span>
                                    <div class="tagcloud">
                                        <a href="blog.html">Education</a>
                                        <a href="blog.html">Online</a>
                                    </div>
                                </div>
                                <div class="col-md-auto text-xl-end">
                                    <span class="share-links-title">Share:</span>
                                    <ul class="social-links">
                                        <li><a href="https://facebook.com/" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="https://twitter.com/" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="https://linkedin.com/" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li><a href="https://instagram.com/" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                    </ul><!-- End Social Share -->
                                </div><!-- Share Links Area end -->
                            </div>
                        </div>
                        
                    </div>
                    <!-- Comment Form -->
                    <div class="as-comment-form ">
                        <div class="form-title">
                            <h3 class="blog-inner-title mb-0">Leave a Comment</h3>
                            <p class="form-text">Your email address will not be published. Required fields are marked *</p>
                        </div>
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <input type="text" placeholder="Your Name*" class="form-control">
                                <i class="fal fa-user"></i>
                            </div>
                            <div class="col-md-6 form-group">
                                <input type="text" placeholder="Your Email*" class="form-control">
                                <i class="fal fa-envelope"></i>
                            </div>
                            <div class="col-12 form-group">
                                <input type="text" placeholder="Website" class="form-control">
                                <i class="fal fa-globe"></i>
                            </div>
                            <div class="col-12 form-group">
                                <textarea placeholder="Write a Comment*" class="form-control"></textarea>
                                <i class="fal fa-pencil"></i>
                            </div>
                            <div class="col-12 form-group mb-0">
                                <button class="as-btn">Post Comment</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-4 col-lg-5">
                    <aside class="sidebar-area">
                        <div class="widget widget_search   ">
                            <form class="search-form">
                                <input type="text" placeholder="Search...">
                                <button type="submit"><i class="far fa-search"></i></button>
                            </form>
                        </div>
                        <div class="widget widget_categories  ">
                            <h3 class="widget_title">Categories</h3>
                            <ul>
                                <li>
                                    <a href="blog.html">UI/UX Design</a>
                                    <span>(10)</span>
                                </li>
                                <li>
                                    <a href="blog.html">Web Development</a>
                                    <span>(22)</span>
                                </li>
                                <li>
                                    <a href="blog.html">Photography</a>
                                    <span>(33)</span>
                                </li>
                                <li>
                                    <a href="blog.html">Learn Music</a>
                                    <span>(20)</span>
                                </li>
                                <li>
                                    <a href="blog.html">Cooking Course</a>
                                    <span>(12)</span>
                                </li>
                                <li>
                                    <a href="blog.html">Technology</a>
                                    <span>(22)</span>
                                </li>
                                <li>
                                    <a href="blog.html">Prototyping</a>
                                    <span>(32)</span>
                                </li>
                            </ul>
                        </div>
                        <div class="widget  ">
                            <h3 class="widget_title">Recent Posts</h3>
                            <div class="recent-post-wrap">
                                <div class="recent-post">
                                    <div class="media-img">
                                        <a href="blog-details.html"><img src="assets/img/blog/recent-post-1-1.jpg" alt="Blog Image"></a>
                                    </div>
                                    <div class="media-body">
                                        <div class="recent-post-meta">
                                            <a href="blog.html"><i class="far fa-calendar"></i>05/03/2022</a>
                                        </div>
                                        <h4 class="post-title"><a class="text-inherit" href="blog-details.html">how to be successful in life</a></h4>
                                    </div>
                                </div>
                                
                        </div>
                        <div class="widget widget_tag_cloud   ">
                            <h3 class="widget_title">Popular Tags</h3>
                            <div class="tagcloud">
                                <a href="blog.html">Business</a>
                                <a href="blog.html">Course</a>
                                <a href="blog.html">Acadu</a>
                                <a href="blog.html">Online</a>
                                <a href="blog.html">Education</a>
                                <a href="blog.html">Study</a>
                                <a href="blog.html">Solution</a>
                                <a href="blog.html">Expert</a>
                                <a href="blog.html">Teaching</a>
                                <a href="blog.html">Learning</a>
                                <a href="blog.html">Book</a>
                            </div>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </section>
    <section class=" " data-pos-for=".footer-wrapper" data-sec-pos="bottom-half">
        <div class="container">
            <div class="cta-wrap">
                <div class="row flex-row-reverse justify-content-between">
                    <div class="col-lg-6">
                        <div class="cta-img">
                            <img src="./education2.jpg" alt="Image">
                        </div>
                    </div>
                    <div class="col-lg-6 align-self-center">
                        <div class="cta-content">
                            <h2 class="fs-40 fw-light text-theme mb-10">Learn From Our Platform</h2>
                            <h2 class="mb-25">That Take You Next Level</h2>
                            <a href="contact.html" class="as-btn">Register Now<i class="fas fa-arrow-right ms-2"></i></a>
                        </div>
                    </div>
                </div>
                <div class="shape-mockup movingX z-index-n1" data-bottom="0%" data-left="44%"><img src="./education2.jpg"  alt="shapes"></div>
            </div>
        </div>
    </section>

<?php
// to include footer
include "layouts/footer_area.php";
?>