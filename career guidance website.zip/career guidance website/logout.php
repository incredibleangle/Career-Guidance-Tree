<?php
// start the problem
session_start();
// unset all the session variable
$_SESSION = array();
session_unset($_SESSION["loggedIN"]);
// destroy the session
session_destroy();
// to redirect the sign in page

header("location: sign_in.php");
exit;

?>