<?php
// condition to check session is already started or not if not then start the  session
if(!isset($_SESSION)) 
{ 
    // to start the session
    session_start(); 
} 
// to check login session is already active or not if active then stay to protected page otherwise redirect to login page

if(!isset($_SESSION["loggedIN"])){
    // to redirect to login page
    header("location:sign_in.php");
}

?>