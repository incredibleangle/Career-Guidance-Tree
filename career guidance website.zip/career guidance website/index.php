<?php 
     include "layouts/header.php";
     include "layouts/header_area.php";
      
     
?>
<!--==============================
Hero Area
==============================-->
<div class="as-hero-wrapper hero-5">
        <div class="hero-slider-5 as-carousel" data-fade="true" data-slide-show="1" data-md-slide-show="1">


            <div class="as-hero-slide">
                <div class="as-hero-bg" data-bg-src="assets/img/hero/hero_bg_5_1.jpg">
                    <img src="assets/img/hero/hero_overlay_5.png" alt="Hero Image">
                </div>
                <div class="container">
                    <div class="hero-style5">
                        <span class="hero-subtitle" data-ani="slideinleft" data-ani-delay="0.1s">Enjoying with destinatio best learning platform</span>
                        <h1 class="hero-title" data-ani="slideinleft" data-ani-delay="0.3s">Find your best career & get</h1>
                        <h1 class="hero-title" data-ani="slideinleft" data-ani-delay="0.5s">opportunity for your future.</h1>
                        <p class="hero-text" data-ani="slideinleft" data-ani-delay="0.6s">you are unique.you have different talents and abilities.you don't have to always follow in the footsteps of others.and most important,you should always remind yourself that you don't have to what everyone else is doing and have a responsibility to develop the talents you have been given.</p>
                        <div class="btn-wrap" data-ani="slideinleft" data-ani-delay="0.7s">
                            <a href="course.html" class="as-btn style3">Explore Courses<i class="fas fa-arrow-right ms-2"></i></a>
                            <a href="https://www.youtube.com/watch?v=_sI_Ps7JSEk" class="video-link popup-video"><span class="play-btn"><i class="fas fa-play"></i></span><span class="btn-text">Watch Video</span></a>
                        </div>
                    </div>
                </div>
            </div>


            

        </div>
        <div class="hero-shape"></div>
    </div>

    <!--==============================
About Area  
==============================-->
<div class="space">
        <div class="container">
            <div class="row">
                <div class="col-xl-6">
                    <div class="img-box7">
                        <div class="img1">
                            <img src="https://tse1.mm.bing.net/th?id=OIP.4YrMXE87TCnL8WEwtqsLmAHaHa&pid=Api&P=0"width="600" height="444" alt="about">
                        </div>
                        <div class="text-end">
                            <div class="img2">
                                <img src="https://tse1.mm.bing.net/th?id=OIP.XNtoool2Ch7nOhWrAY0F5gHaEK&pid=Api&P=0" width="353" height="250" alt="about">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="title-area mb-35">
                        <span class="sub-title">More About Us</span>
                        <h2 class="sec-title fw-semibold">All In One Education Solution Makes Your Better Skillsy</h2>
                    </div>
                    <p class="mt-n2 mb-35">Credibly syndicate transparent interfaces and client-focused synergy. Objectively embrace revolutionary infomediaries virtual functionalities. Monotonectally myocardinate client-based processes before intermandated models prospective.</p>
                    <a href="about.html" class="as-btn">Learn More<i class="fas fa-arrow-right ms-2"></i></a>
                </div>
            </div>
            <div class="row justify-content-end">
                <div class="col-xxl-10">
                    <div class="row moto-box-wrap">
                        <div class="col-md-6 col-lg-4">
                            <div class="moto-box">
                                <div class="moto-box_icon">
                                    <img src="assets/img/icon/moto_1_1.png" alt="icon">
                                </div>
                                <h5 class="moto-box_title">Our Mission</h5>
                                <p class="moto-box_text">let the students know every worldwide ooportubities at their every step.</p>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="moto-box">
                                <div class="moto-box_icon">
                                    <img src="assets/img/icon/moto_1_2.png" alt="icon">
                                </div>
                                <h5 class="moto-box_title">Our Vision</h5>
                                <p class="moto-box_text">we want to help the students who meke mistakes in lack of knowlege of career options.</p>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="moto-box">
                                <div class="moto-box_icon">
                                    <img src="assets/img/icon/moto_1_3.png" alt="icon">
                                </div>
                                <h5 class="moto-box_title">Our Goals</h5>
                                <p class="moto-box_text">to make you the master of your life by chooosing right options at right time.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--==============================
Course Area  
==============================-->
<section class="space" data-bg-src="assets/img/bg/category_bg_1.jpg">
        <div class="container">
            <div class="row justify-content-center justify-content-xl-between align-items-center">
                <div class="col-xl-8 mb-n2 mb-xl-0">
                    <div class="title-area text-center text-xl-start">
                        <span class="sub-title">INSTRUCTORS & STUDENTS</span>
                        <h2 class="sec-title fw-semibold">Choose Your Current Class</h2>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="sec-btn">
                        <a href="course.php" class="as-btn">View All<i class="fas fa-arrow-right ms-2"></i></a>
                    </div>
                </div>
            </div>
            <div class="row gy-4">
                <div class="col-lg-6 col-xl-4">
                    <div class="category-list">
                        <div class="category-list_icon">
                            <img src="assets/img/icon/category_2_1.svg" alt="icon">
                        </div>
                        <div class="category-list_content">
                            <h3 class="category-list_title"><a href="course.php">Class V</a></h3>
                            <span class="category-list_text">256 Courses</span>
                        </div>
                        <a href="course.php" class="icon-btn"><i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-4">
                    <div class="category-list">
                        <div class="category-list_icon">
                            <img src="assets/img/icon/category_2_1.svg" alt="icon">
                        </div>
                        <div class="category-list_content">
                            <h3 class="category-list_title"><a href="course.php">Class VI</a></h3>
                            <span class="category-list_text"></span>
                        </div>
                        <a href="course.php" class="icon-btn"><i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-4">
                    <div class="category-list">
                        <div class="category-list_icon">
                            <img src="assets/img/icon/category_2_1.svg" alt="icon">
                        </div>
                        <div class="category-list_content">
                            <h3 class="category-list_title"><a href="course.php">Class VII</a></h3>
                            <span class="category-list_text">456 Courses</span>
                        </div>
                        <a href="course.html" class="icon-btn"><i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-4">
                    <div class="category-list">
                        <div class="category-list_icon">
                            <img src="assets/img/icon/category_2_1.svg" alt="icon">
                        </div>
                        <div class="category-list_content">
                            <h3 class="category-list_title"><a href="course.php">Class VIII</a></h3>
                            <span class="category-list_text">156 Courses</span>
                        </div>
                        <a href="course.php" class="icon-btn"><i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-4">
                    <div class="category-list">
                        <div class="category-list_icon">
                            <img src="assets/img/icon/category_2_1.svg" alt="icon">
                        </div>
                        <div class="category-list_content">
                            <h3 class="category-list_title"><a href="course.php">Class IX</a></h3>
                            <span class="category-list_text">220 Courses</span>
                        </div>
                        <a href="course.php" class="icon-btn"><i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-4">
                    <div class="category-list">
                        <div class="category-list_icon">
                            <img src="assets/img/icon/category_2_1.svg" alt="icon">
                        </div>
                        <div class="category-list_content">
                            <h3 class="category-list_title"><a href="course.php">Class X</a></h3>
                            <span class="category-list_text">230 Courses</span>
                        </div>
                        <a href="course.php" class="icon-btn"><i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-4">
                    <div class="category-list">
                        <div class="category-list_icon">
                            <img src="assets/img/icon/category_2_1.svg" alt="icon">
                        </div>
                        <div class="category-list_content">
                            <h3 class="category-list_title"><a href="course.html">Class XI</a></h3>
                            <span class="category-list_text">226 Courses</span>
                        </div>
                        <a href="course.php" class="icon-btn"><i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-4">
                    <div class="category-list">
                        <div class="category-list_icon">
                            <img src="assets/img/icon/category_2_1.svg" alt="icon">
                        </div>
                        <div class="category-list_content">
                            <h3 class="category-list_title"><a href="course.html"></a>Class XII</h3>
                            <span class="category-list_text">346 Courses</span>
                        </div>
                        <a href="course.html" class="icon-btn"><i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-4">
                    <div class="category-list">
                        <div class="category-list_icon">
                            <img src="assets/img/icon/category_2_1.svg" alt="icon">
                        </div>
                        <div class="category-list_content">
                            <h3 class="category-list_title"><a href="course.html">business/b.tech</a></h3>
                            <span class="category-list_text">310 Courses</span>
                        </div>
                        <a href="course.html" class="icon-btn"><i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
        

                
    <!--==============================
Cta Area  
==============================-->
<!--<section class="space position-relative">
        
            <img src="assets/img/bg/bg_overlay_1.png" alt="overlay">
        </div>
        <div class="container text-center">
            <div class="title-area text-center mb-40">
                <span class="sub-title text-white"><i class="fal fa-book me-2"></i></span>
                <h2 class="sec-title text-white"><br> <span class="fw-light"></span></h2>
            </div>
            <div class="btn-group justify-content-center">
                
            </div>
        </div>
    </section>-->

    <!--==============================
Testimonial Area  
==============================-->
<section class="space overflow-hidden" data-bg-src="assets/img/bg/testi_bg_2.jpg">
        <div class="container">
            <div class="title-area text-center">
                <span class="sub-title">What Student Says</span>
                <h2 class="sec-title fw-semibold text-white">Student’s Testimonials</h2>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row gx-40" id="testiSlide1">
                <div class="col-lg-6">
                    <div class="testi-grid">
                        <p class="testi-grid_text">“Quickly maximize visionary solutions after mission critical action items productivate premium portals for impactful -services stinctively negotiate enabled niche solutions markets via growth enabled niche growth strategies”</p>
                        <div class="testi-grid_bottom">
                            <div class="testi-grid_author">
                                <div class="testi-grid_avater">
                                    <img src="assets/img/testimonial/testi_1_1.jpg" alt="Avater">
                                </div>
                                <div>
                                    <h3 class="testi-grid_name">Vlademir Hilton</h3>
                                    <span class="testi-grid_desig">IT Student</span>
                                </div>
                            </div>
                            <div class="testi-grid_review">
                                <i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="testi-grid">
                        <p class="testi-grid_text">“Markets maximize visionary solutions after mission critical action items productivate premium portals for impactful -services stinctively negotiate enabled niche markets solutions via growth strategies enabled niche growth”</p>
                        <div class="testi-grid_bottom">
                            <div class="testi-grid_author">
                                <div class="testi-grid_avater">
                                    <img src="assets/img/testimonial/testi_1_2.jpg" alt="Avater">
                                </div>
                                <div>
                                    <h3 class="testi-grid_name">David Milton</h3>
                                    <span class="testi-grid_desig">CSE Student</span>
                                </div>
                            </div>
                            <div class="testi-grid_review">
                                <i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="testi-grid">
                        <p class="testi-grid_text">“Mission maximize visionary solutions after mission critical action items productivate premium portals for impactful -services stinctively negotiate enabled niche markets solutions via growth enabled niche strategies growth”</p>
                        <div class="testi-grid_bottom">
                            <div class="testi-grid_author">
                                <div class="testi-grid_avater">
                                    <img src="assets/img/testimonial/testi_1_3.jpg" alt="Avater">
                                </div>
                                <div>
                                    <h3 class="testi-grid_name">Abraham Khalil</h3>
                                    <span class="testi-grid_desig">GS Student</span>
                                </div>
                            </div>
                            <div class="testi-grid_review">
                                <i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="testi-grid">
                        <p class="testi-grid_text">“Mission maximize visionary solutions after mission solutions critical action items productivate premium portals for impactful -services stinctively negotiate enabled niche markets via growth strategies enabled growth niche”</p>
                        <div class="testi-grid_bottom">
                            <div class="testi-grid_author">
                                <div class="testi-grid_avater">
                                    <img src="assets/img/testimonial/testi_1_4.jpg" alt="Avater">
                                </div>
                                <div>
                                    <h3 class="testi-grid_name">Sowat Ahsan</h3>
                                    <span class="testi-grid_desig">CSE Student</span>
                                </div>
                            </div>
                            <div class="testi-grid_review">
                                <i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i><i class="fa-solid fa-star-sharp"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php

include "layouts/footer_area.php";

?>