
<?php
// to include auth.php file which have code for checking login session exist or not 
// if session not available redirect to login page
include "auth.php";
?>
<?php 

// to include header file 
     include "layouts/header.php";
     include "layouts/header_area.php";
?>

<h4>Under Development</h4>

<?php
// to include footer
include "layouts/footer_area.php";
?>