<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration</title>
    <style>
        *{
            padding:0;
            margin:0;
            box-sizing: border-box;
        }
        body{
            background:rgb(30, 30, 196);
        }
        .row{
            background:white;
            border-radius: 30px;
            box-shadow:  12px 12px 22px blue;
        }
        img{
            border-top-left-radius: 30px;
            border-bottom-left-radius: 30px;
        }
    .btnl{
        border: none;
        outline: none;
        height: 50px;
        width: 100%;
        background-color:black ;
        color: white;
        border-radius: 4px;
        font-weight: bold;
    }
.btnl:hover{
    background:white;
    border:1px solid;
    color:black;
}
        
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body>
    <section class=" Form my-4 mx-5">
        <div class="container">
        <div class="row no-gutters">
        <div class="col-lg-5">
            <img src="./book image.jpg" class="img-fluid" alt="">
        </div>
        <div class="col-lg-7 px-5 pt-5">
            <h4>Register your account</h4>
            <form action="" method="POST">
                <div class="form-row">
                    <div class="col-lg-7">
                        <input type="text" placeholder="Name" name="user_name" class="form-control my-1 p-2">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-lg-7">
                        <input type="email" placeholder="Email-Address" name="email" class="form-control my-1 p-2">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-lg-7">
                        <input type="number" placeholder="Mobile" name="number" class="form-control my-1 p-2">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-lg-7">
                        <input type="password" placeholder="Password" name="password" class="form-control  my-1 p-1">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-lg-7">
                        <input type="confirm password" placeholder="Confirm-Password" name="confirm_password" class="form-control  my-1 p-1">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-lg-7">
                       <button type="submit" name="submit" class="btnl mt-3 mb-5">Submit</button>
                    </div>
                </div>
                <p>Already have an account? <a href="sign_in.php">Login</a></p>
            </form>
        </div>
    </div>
</div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>
<?php
// this is to include database connection file
include "layouts/db_connection.php";
// / isset function is used to check the variable is set or not $_POST['submit'] will set when user will submit form 
// so i have use if condition to excute php code after clicking submit button 
if(isset($_POST['submit'])){

//below  code is written to store data in variable from array which is received from html form
$Name=$_POST['user_name'];
$Email=$_POST['email'];
$Phone=$_POST['number'];
$Password=$_POST['password'];
$Confirm_Password=$_POST['confirm_password'];
// below condition is for checking password and confirm password is same or not
if($Password==$Confirm_Password){

 //below is  sql query to select from database to check user exist or not                                                 
$sql = "SELECT * FROM `users` WHERE Email='$Email'";
// below line is for executing sql query
$result = mysqli_query($conn,$sql);
// mysqli_num_rows function is used to get row count of result
$num = mysqli_num_rows($result);
// below condition is checking user existance
if($num>0){
   //echo"already exist";
   echo '<script>alert("Already Exists");</script>';
}
        else
        {
            // user does not exist means $num is less then zero then performing database inserting action
            $sql = "INSERT INTO users (Name,Email,Phone,Password) VALUES('$Name','$Email','$Phone','$Password')";
            $result = mysqli_query($conn,$sql);
        }
    }
    else {
        echo '<script>alert("Confirm password does not match");</script>';
    }
        
}
