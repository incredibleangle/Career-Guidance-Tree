<?php 
    // below line is used to include database connection code which is written in db_connection.php
    include "layouts/db_connection.php";
    // below lines are used to include header and menu bar code 
     include "layouts/header.php";
     include "layouts/header_area.php";
      
     
?>

<!--==============================
    Breadcumb
============================== -->
<div class="breadcumb-wrapper " data-bg-src="assets/img/breadcumb/breadcumb-bg.jpg">
        <div class="container z-index-common">
            <h1 class="breadcumb-title">Contact Us</h1>
            <ul class="breadcumb-menu">
                <li><a href="index.php">Home</a></li>
                <li>Contact Us</li>
            </ul>
        </div>
    </div>

            <div class="contact-form-wrap" data-bg-src="assets/img/bg/contact_bg_1.png">
                <span class="sub-title">Contact With Us!</span>
                <h2 class="border-title">Have Any Questions?</h2>
                <p class="mt-n1 mb-25 sec-text">Lorem ipsum dolor sit amet adipiscing elit, sed do eiusmod tempor eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                <form action="" method="POST" class="contact-form ajax-contact">
                    <div class="row">
                        <div class="form-group col-md-6">
                            <input type="text" class="form-control style3" name="name" id="name" placeholder="Enter Your Name">
                            <i class="fal fa-user"></i>
                        </div>
                        <div class="form-group col-md-6">
                            <input type="email" class="form-control style3" name="email" id="email" placeholder="Email Address">
                            <i class="fal fa-envelope"></i>
                        </div>
                        <div class="form-group col-md-6">
                            <input type="tel" class="form-control style3" name="number" id="number" placeholder="Phone Number">
                            <i class="fal fa-phone"></i>
                        </div>
                        <div class="form-group col-12">
                            <textarea name="message" id="message" cols="30" rows="3" class="form-control style3" placeholder="Your Message"></textarea>
                            <i class="fal fa-comment"></i>
                        </div>
                        <div class="form-btn col-12 mt-10">
                            <button type="submit" name="save" class="as-btn">Send Message<i class="fas fa-long-arrow-right ms-2"></i></button>
                        </div>
                    </div>
                    <p class="form-messages mb-0 mt-3"></p>
                </form>
            </div>
        </div>
    </section>
    <?php

// isset function is used to check the variable is set or not $_POST['save'] will set when user will submit form 
// so i have use if condition to excute php code after clicking submit button 
    if(isset($_POST['save'])){
        // below lines are used to store the form the into variable from array
        $name=$_POST['name'];
        $email=$_POST['email'];
        $phone=$_POST['number'];
        $message=$_POST['message'];
// this is sql query to insert data in to mysql database
        $sql = "INSERT INTO studentsinfo (name,email,number,message) VALUES('$name','$email','$phone','$message')";
        // mysqli_query($conn,$sql) is function to perform the query
        if(mysqli_query($conn,$sql)){
            // this is to show a javascript alert after from submission
            echo '<script>alert("Query Submitted Successfully");</script>';
        }else{
            //this is to show a javascript alert if query not executed due to any error
            echo '<script>alert("Server Error!!");</script>';
        }
        
    }
// this is to include footer area
include "layouts/footer_area.php";

?>