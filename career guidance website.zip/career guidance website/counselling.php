<?php 
     include "layouts/header.php";
     include "layouts/header_area.php";
      
     
?>
<style>
		/*Now the CSS*/


.treee ul {
	padding-top: 20px; position: relative;
	
	transition: all 0.5s;
	-webkit-transition: all 0.5s;
	-moz-transition: all 0.5s;
}

.treee li {
	float: left; text-align: center;
	list-style-type: none;
	position: relative;
	padding: 20px 5px 0 5px;
	
	transition: all 0.5s;
	-webkit-transition: all 0.5s;
	-moz-transition: all 0.5s;
}

/*We will use ::before and ::after to draw the connectors*/

.treee li::before, .treee li::after{
	content: '';
	position: absolute; top: 0; right: 50%;
	border-top: 1px solid rgb(21, 69, 240);
	width: 50%; height: 20px;
}
.treee li::after{
	right: auto; left: 50%;
	border-left: 1px solid rgb(21, 69, 240);
}

/*We need to remove left-right connectors from elements without 
any siblings*/
.treee li:only-child::after, .treee li:only-child::before {
	display: none;
}

/*Remove space from the top of single children*/
.treee li:only-child{ padding-top: 0;}

/*Remove left connector from first child and 
right connector from last child*/
.treee li:first-child::before, .treee li:last-child::after{
	border: 0 none;
}
/*Adding back the vertical connector to the last nodes*/
.treee li:last-child::before{
	border-right: 1px solid rgb(21, 69, 240);
	border-radius: 0 5px 0 0;
	-webkit-border-radius: 0 5px 0 0;
	-moz-border-radius: 0 5px 0 0;
}
.treee li:first-child::after{
	border-radius: 5px 0 0 0;
	-webkit-border-radius: 5px 0 0 0;
	-moz-border-radius: 5px 0 0 0;
}

/*Time to add downward connectors from parents*/
.treee ul ul::before{
	content: '';
	position: absolute; top: 0; left: 50%;
	border-left: 1px solid rgb(21, 69, 240);
	width: 0; height: 20px;
}

.treee li a{
	border: 1px solid rgb(21, 69, 240);
	padding: 5px 10px;
	text-decoration: none;
	color: #666;
	font-family: arial, verdana, tahoma;
	font-size: 11px;
	display: inline-block;
    text-shadow: 2px;
	
	border-radius: 5px;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	
	transition: all 0.5s;
	-webkit-transition: all 0.5s;
	-moz-transition: all 0.5s;
}

/*Time for some hover effects*/
/*We will apply the hover effect the the lineage of the element also*/
.treee li a:hover, .treee li a:hover+ul li a {
	background: #c8e4f8; color: #000; border: 1px solid #94a0b4;
}
/*Connector styles on hover*/
.treee li a:hover+ul li::after, 
.treee li a:hover+ul li::before, 
.treee li a:hover+ul::before, 
.treee li a:hover+ul ul::before{
	border-color:  #94a0b4;
}
	</style>
<!--==============================
Hero Area
==============================-->
<?php
$class="-1";
if(isset($_GET['class'])){
$class=$_GET['class'];
}
?>
<div class="as-hero-wrapper hero-3">
        <div class="container z-index-common">
       
            <div class="">
                
                <h1 class="hero-title">Choose Your Class And Get Career Path</h1>
                <p class="hero-text">Destinatio is leading online self counselling platform.</p>
                <form class="search-form">
                    <div class="form-group">
                        <select name="classs" style="border:solid;" id="choose_career" onchange="generate_tree(this.value)">
                        <option value="" <?php if($class==-1){echo "selected";}?>>Select Your Course</option>
                         <option value="0" <?php if($class==0){echo "selected";}?>>Class 5</option>
                         <option value="1" <?php if($class==1){echo "selected";}?>>Class 10</option>
                         <option value="2"<?php if($class==2){echo "selected";}?>>Class 12</option>
                         <option value="3"<?php if($class==3){echo "selected";}?>>Btech</option>
                        </select>
                       
                    </div>
                    
                </form>
                <div class="hero-counter-wrap">
                <div class="treee">
              


<?php
if(isset($_GET['class'])){
    $class=$_GET['class'];
    $text=$_GET['text'];
    echo "<h5 style='border: solid; border-radius: 10px; border-color: blue; background-color: antiquewhite; color: black; text-align: center; float: centre;'>After $text, You have these career opportunity</h5>";
include "layouts/db_connection.php";
$res=mysqli_query($conn,"select * from city");
$arr=[];
while($row=mysqli_fetch_assoc($res)){
	$arr[$row['id']]['city']=$row['city'];
	$arr[$row['id']]['parent_id']=$row['parent_id'];
}
buildTreeView($arr,$class);
}
function buildTreeView($arr,$parent,$level = 0,$prelevel = -1){
	foreach($arr as $id=>$data){
		if($parent==$data['parent_id']){
			if($level>$prelevel){
				echo "<ul>";
			}
			if($level==$prelevel){
				echo "</li>";
			}
			echo "<li><a>".$data['city']."</a>";
			if($level>$prelevel){
				$prelevel=$level;
			}
			$level++;
			buildTreeView($arr,$id,$level,$prelevel);
			$level--;	
		}
	}
	if($level==$prelevel){
		echo "</li></ul>";
	}
}

//echo "<pre>";
//print_r($arr);
?>
        </div>
                </div>
            </div>
        </div>
        <div class="hero-img1">
            
       
    
        </div>
        
        </div>
        <!--======== / Hero Section ========-->
    </div>
<script>
    function generate_tree(a) {
        var s = document.getElementById("choose_career");
        var b = s.options[s.selectedIndex].text;
        window.location.href = "counselling.php?class="+a+"&text="+b;
	
}


</script>
<!--==============================
Hero Area
==============================-->
<div class="as-hero-wrapper hero-3">
        <div class="container z-index-common">
            <div class="hero-style3">
                <h1 class="hero-title">Start learning from the world’s best sites</h1>
                <p class="hero-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec toroa ullamcorper mattis</p>
                <form class="search-form">
                    <div class="form-group">
                        <select name="class" id="choose_career" onchange="generate_tree(this.value)">
                         <option value="0">Class 5</option>
                         <option value="1">Class 10</option>
                         <option value="2">Class 12</option>
                         <option value="3">Btech</option>
                        </select>
                       
                    </div>
                    
                </form>
                <div class="hero-counter-wrap">
                    <div class="hero-counter">
                        <div class="hero-counter_icon">
                            <img src="assets/img/icon/hero_counter_1.svg" alt="icon">
                        </div>
                        <div>
                            <h2 class="hero-counter_number"><span class="counter-number">7500</span>+</h2>
                            <span class="hero-counter_text">COURSES</span>
                        </div>
                    </div>
                    <div class="hero-counter">
                        <div class="hero-counter_icon">
                            <img src="assets/img/icon/hero_counter_2.svg" alt="icon">
                        </div>
                        <div>
                            <h2 class="hero-counter_number"><span class="counter-number">165000</span>+</h2>
                            <span class="hero-counter_text">STUDENTS</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hero-img1">
            <img src="assets/img/hero/hero_img_3_1.png" alt="Hero Image">
        </div>
        <div class="hero-shape shape1">
            <img src="assets/img/hero/shape_3_1.png" alt="shape">
        </div>
        <div class="hero-shape shape2">
            <img src="assets/img/hero/shape_3_2.png" alt="shape">
        </div>
        <div class="hero-shape shape3">
            <img src="assets/img/hero/shape_3_3.png" alt="shape">
        </div>
        <div class="hero-shape shape4">
            <img src="assets/img/hero/shape_3_4.png" alt="shape">
        </div>
        <div class="hero-shape shape5">
            <img src="assets/img/hero/shape_3_5.png" alt="shape">
        </div>
        <div class="hero-shape shape6">
            <img src="assets/img/hero/shape_3_6.png" alt="shape">
        </div>
    </div>
    <!--======== / Hero Section ========-->
<?php

include "layouts/footer_area.php";

?>