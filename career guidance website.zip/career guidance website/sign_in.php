<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign In</title>
    <style>
        *{
            padding:0;
            margin:0;
            box-sizing: border-box;
        }
        body{
            background:rgb(30, 30, 196);
        }
        .row{
            background:white;
            border-radius: 30px;
            box-shadow:  12px 12px 22px blue;
        }
        img{
            border-top-left-radius: 30px;
            border-bottom-left-radius: 30px;
        }
    .btnl{
        border: none;
        outline: none;
        height: 50px;
        width: 100%;
        background-color:black ;
        color: white;
        border-radius: 4px;
        font-weight: bold;
    }
.btnl:hover{
    background:white;
    border:1px solid;
    color:black;
}
        
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body>
    <section class=" Form my-4 mx-5">
        <div class="container">
        <div class="row no-gutters">
        <div class="col-lg-5">
            <img src="./book_image.jpg" class="img-fluid" alt="">
        </div>
        <div class="col-lg-7 px-5 pt-5">
            <h4>Sign into your account</h4>
            <form action="" method="POST">
                <div class="form-row">
                    <div class="col-lg-7">
                        <input type="email" name="email" placeholder="Email-Address" class="form-control my-1 p-2">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-lg-7">
                        <input type="password" name="password" placeholder="*********" class="form-control  my-1 p-1">
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-lg-7">
                       <button type="submit" class="btnl mt-3 mb-5">Login</button>
                    </div>
                </div>
                <a href="#">Forgot password</a>
                <p>Don't have an account? <a href="registration.php">Register here</a></p>
            </form>
        </div>
    </div>
</div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>

<?php
// session_start is used to start session
session_start();
//below  line is checking session is already set or not which we have set while performing login action 
// if already set then auto redirect to dashboard page with out relogin
if(isset($_SESSION["loggedIN"])){
    // to redirect dashboard page
    header("location:dashboard.php");
}
// below line is used to include database file
include "layouts/db_connection.php";
// below line is used to check $_post['email'] and $_post['password'] is set or not if set then execute further php code otherwise no
if(isset($_POST['email']) && isset($_POST['password'])){
// to store form data in variable
$email=$_POST['email'];
$pass=$_POST['password'];
// query is written to select from database
$sql="SELECT id FROM users WHERE email = '$email' AND password = '$pass'";
// to execute query
$result=mysqli_query($conn,$sql);
// mysqli_num_rows function to get count of returned row in above query
// if greater then zero means login creditials matched make user login else show alert
if(mysqli_num_rows($result)==1){
    // session_start(); to start the session
    session_start();
    // to set session variable 
    $_SESSION["loggedIN"]=true;

    // after login redirect to dashboard.php page
    header("location: dashboard.php");


}else{
    // to show alert if password or email is wrong
    echo '<script>alert("Wrong email or Password");</script>';
}

}


?>