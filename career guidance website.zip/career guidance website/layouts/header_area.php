<!--==============================
	Header Area
==============================-->
<header class="as-header header-layout5">
        <div class="top-area" data-bg-src="assets/img/bg/header_bg_1.png">
            <div class="header-top">
                <div class="container">
                    <div class="row justify-content-center justify-content-md-between align-items-center">
                        <div class="col-auto">
                            <p class="header-notice">Welcome to Career Counselling Platform</p>
                        </div>
                        <div class="col-auto d-none d-md-block">
                            <div class="header-links">
                                <ul>
                                    <?php
                                    // condition to check session is already started or not if not then start the  session
                                    if(!isset($_SESSION)) 
                                    { 
                                        // to start the session
                                        session_start(); 
                                    } 
                                    // to check login session is already active or not  
                                    if(!isset($_SESSION["loggedIN"]) || $_SESSION["loggedIN"]!==true){
                                        // if login session not active then echo sign register button
                                   echo  '<li><i class="far fa-user"></i><a href="sign_in.php">Sign In</a></li>
                                    <li><i class="far fa-user"></i><a href="registration.php">Register</a></li>';
                                    }else{
                                        // if login session t active then echo logout button
                                        echo '<li><i class="far fa-user"></i><a href="logout.php">Logout</a></li>';
                                    }
                                    ?>
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="menu-top">
                <div class="container">
                    <div class="row align-items-center justify-content-center justify-content-sm-between">
                        <div class="col-auto d-none d-sm-block">
                            <a class="header-link" href="tel:+00000000"><i class="icon-btn fas fa-phone"></i>00 000 000 0000</a>
                            <a class="header-link d-none d-lg-inline-block" href="mailto:info@destinatio.com"><i class="icon-btn fas fa-envelope"></i>info@destinatio.com</a>
                            <span class="header-link d-none d-xl-inline-block"><i class="icon-btn fas fa-clock"></i>27*7 Guidance</span>
                        </div>
                        <div class="col-auto">
                            <div class="as-social">
                                <a target="_blank" href="https://facebook.com/"><i class="fab fa-facebook-f"></i></a>
                                <a target="_blank" href="https://twitter.com/"><i class="fab fa-twitter"></i></a>
                                <a target="_blank" href="https://instagram.com/"><i class="fab fa-instagram"></i></a>
                                <a target="_blank" href="https://pinterest.com/"><i class="fab fa-pinterest-p"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="sticky-wrapper">
            <div class="sticky-active">
                <div class="menu-area">
                    <div class="container">
                        <div class="row align-items-center justify-content-between">
                            <div class="col-auto">
                                <div class="header-logo">
                                    <a href="index.php">Destinatio</a>
                                </div>
                            </div>
                            <div class="col-auto">
                                <div class="row align-items-center justify-content-between">
                                    <div class="col-auto">
                                        <nav class="main-menu d-none d-lg-inline-block">
                                            <ul>
                                                <li>
                                                    <a href="index.php">Home</a>
                                                    </li>
                                               
                                                <li>
                                                    <a href="counselling.php">Counselling</a>
                                                </li>
                                                <li>
                                                    <a href="contact.php">Contact Us</a>
                                                </li>
                                                
                                                <li>
                                                    <a href="blog.php">Blogs</a>
                                                </li>        
                                                        
                                            
                                                    </ul>
                                                </li>
                                                
                                               
                                            </ul>
                                        </nav>
                                        <button type="button" class="as-menu-toggle d-inline-block d-lg-none"><i class="far fa-bars"></i></button>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="logo-shape" data-bg-src="assets/img/bg/pattern_bg_1.png"></div>
                </div>
            </div>
        </div>
    </header>