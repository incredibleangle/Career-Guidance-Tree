<?php
$serverrname = "localhost";
$dbName = "root";
$dbPassword= "";
$db="gunjan";

$conn = mysqli_connect($serverrname, $dbName, $dbPassword, "gunjan");  

?>