<?php
$name=" ";
$email=" ";
$phone=" ";
$message=" ";

$name= $_POST['username'];
$name= $_POST['useremail'];
$name= $_POST['phone'];
$name= $_POST['message'];

echo $name;
echo $email;
echo $phone;
echo $message;

?>