<!--==============================
	Footer Area
==============================-->
<footer class="footer-wrapper footer-layout1">
        <div class="widget-area">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-md-6 col-xxl-3 col-xl-4">
                        <div class="widget footer-widget">
                            <div class="as-widget-about">
                                <div class="about-logo">
                                    <a href="index.html"><img src="assets/img/logo-white.svg" alt="Destinatio"></a>
                                </div>
                                <p class="about-text">you take every opportunity given you in this world,even if you have too many opportunities.one day,the opportunities stop,you kmow. and you know that success is taking advantage of every opportunities.</p>
                                <h4 class="footer-info-title">Follow Us On:</h4>
                                <div class="as-social">
                                    <a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a>
                                    <a href="https://www.twitter.com/"><i class="fab fa-twitter"></i></a>
                                    <a href="https://www.linkedin.com/"><i class="fab fa-linkedin-in"></i></a>
                                    <a href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a>
                                    <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-auto">
                        <div class="widget widget_nav_menu footer-widget">
                            <h3 class="widget_title">Quick link</h3>
                            <div class="menu-all-pages-container">
                                <ul class="menu">
                                    <li><a href="team.html">Counselling</a></li>
                                    <li><a href="team.html">Contact us</a></li>
                                    <li><a href="team.html">Blogs</a></li>
                                    
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-auto">
                        <div class="widget widget_nav_menu footer-widget">
                            <h3 class="widget_title">Resources</h3>
                            <div class="menu-all-pages-container">
                                <ul class="menu">
                                    <li><a href="team.html">Community</a></li>
                                    <li><a href="contact.html">Support</a></li>
                                    <li><a href="course.html">Video Guides</a></li>
                                    <li><a href="about.html">Documentation</a></li>
                                    <li><a href="course.html">Security</a></li>
                                    <li><a href="course.html">Template</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-3">
                        <div class="widget footer-widget">
                            <h3 class="widget_title">Get in touch!</h3>
                            <form class="newsletter-widget">
                                <p class="footer-text">you can reach us via.........</p>
                                <div class="form-group">
                                    <input class="form-control" type="email" placeholder="Enter Email" required="">
                                    <i class="fal fa-envelope"></i>
                                </div>
                                <button type="submit" class="as-btn shadow-none">Subscribe</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="copyright-wrap">
                <div class="row justify-content-between align-items-center">
                    <div class="col-lg-6">
                        <p class="copyright-text">Copyright <i class="fal fa-copyright"></i> 2022 <a href="">Destinatio</a>. All Rights Reserved.</p>
                    </div>
                    <div class="col-lg-6 text-end d-none d-lg-block">
                        <div class="footer-links">
                            <ul>
                                <li><a href="about.html">Privacy Policy</a></li>
                                <li><a href="about.html">Terms of Use</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="shape-mockup jump d-none d-xl-block" data-top="24%" data-left="4%"><img src="assets/img/shape/footer_shape_1.png" alt="shapes"></div>
        <div class="shape-mockup jump-reverse d-none d-xl-block" data-bottom="20%" data-right="4%"><img src="assets/img/shape/footer_shape_2.png" alt="shapes"></div>
        <div class="shape-mockup" data-top="0" data-right="0"><img src="assets/img/shape/footer_shape_3.png" alt="shapes"></div>
    </footer>

